# Power Play Sports Stats Manager PWA

A free, mobile-friendly, installable scorebook with separate Hockey, Soccer, and Lacrosse stat modules. Additional sport names can be added from Settings.

## What is included
- Sport selector for Hockey, Soccer, Lacrosse, plus user-added sports
- Separate in-progress game state by sport, team, and season
- Named seasons and multiple teams
- Team-specific accent and secondary colors
- Family child profiles managed in Settings and linked to the matching player on the team roster; select a child on Dashboard or Game Mode to keep games, schedule, and personal stats organized by child
- Player roster with jersey numbers and positions
- Game type, opponent, rink/field, date, start time, home/away and position
- Live scoreboard with score correction
- Team-wide goal logging: select any roster player as scorer and optionally record an assister, with the team scoreboard updated for every logged goal
- Child-only individual tracking for shots, shots on goal, sport-specific stats, shifts, penalties, and shootout attempts; these entries are automatically credited to the linked child without choosing a roster player each time
- Hockey stats: faceoff wins, hits, blocked shots, takeaways, giveaways, plus/minus, penalty minutes, shifts and shootouts
- Soccer stats: shot attempts, shots on goal, saves, tackles, interceptions, clearances, crosses, corners and offsides
- Lacrosse stats: shot attempts, shots on goal, saves, faceoff wins, ground balls, caused turnovers, clears and takeaways
- Additional sports start with general attempts, successful attempts, saves, tackles and turnovers
- Hockey penalty logging, including minor, double minor, major, misconduct and game misconduct
- Game notes, schedule filters, saved-game review, season totals and shooting percentages
- Clear in-app guidance showing which sections require a roster player dropdown and which are team-level / do not need one
- Trend chart, child-labeled CSV export, JSON backup and restore
- Offline PWA cache after first successful online load

## Data preservation and legacy soccer migration
The app continues to use IndexedDB database `eightUManagerDB` and object store `state`. On first launch, it reads the existing `app` record. For the legacy single-team record shape (`teamName`, `players`, `games`, `current`, `settings`), it first writes an untouched copy to `legacy_backup_before_sports_upgrade`, then migrates the roster, saved games, current match, team name and team colors into the new season/team structure. Migrated legacy games and the current match are labeled Soccer.

**Important:** before replacing the files on GitHub Pages, open the old app on the device containing your records and download a JSON backup. Keep that backup safe. Publish these files to the same repository and open the upgraded app in the same browser profile. Do not clear browser/site data during the upgrade. A synthetic legacy-data migration fixture is included in the development checks, but the exact original app ZIP/database was not part of this delivery, so migration should still be confirmed against a backup from your own original app before deleting or overwriting the old deployment.

## Family child profiles and game views
Open **Settings → Family child profiles** and add each child by name. The active child can be selected from the Dashboard or Game Mode. Each newly created game is assigned to the selected child; Schedule and Stats show games for that child. With exactly one child profile, Game Mode automatically uses that child and hides the selector to avoid an unnecessary extra step. With multiple profiles, use the child selector to switch the view. Existing games created before child profiles were added remain unassigned and are visible in each child's view for backwards compatibility. Removing a child profile does not delete saved games.

The team roster remains a shared team roster. For each family child, use Settings → Family child profiles and choose the matching player from the team roster. The link is saved per team, so the same child can be linked to a different roster entry on another team. **Goals are team-wide:** when recording a goal, choose any roster player as scorer and optionally choose an assister. The scoreboard increases for every logged team goal. The child receives goal/assist credit only when their linked roster player is the scorer or assister. **All other individual stats belong to the selected child:** shots, player-stat buttons, shifts, penalties, and shootout attempts automatically use the linked roster player and do not show a roster dropdown. The Stats page and CSV export show only the linked child’s individual totals. The scoreboard, team-wide notes, event history, season/team setup, and schedule do not need a player dropdown. If the child is not linked, individual stat buttons prompt you to set up the roster link first.

## Parent-specific data
Data is stored in IndexedDB in each browser profile. Parents using separate devices or browser profiles have separate copies. There are no cloud accounts, family login, or automatic sync between parents/devices. Use JSON backup/restore to transfer data. A family can create multiple child profiles inside one parent's copy; these profiles do not sync to another parent's device.

## Known limitations
- **Google Sheets automatic synchronization is not configured.** Current workflow: in Stats, choose **Export CSV**; in Google Sheets, open a spreadsheet and choose **File → Import → Upload**, select the CSV, then import it as a new sheet or replace the current sheet. The CSV includes the selected child, their linked roster player, season, team, sport, and that child’s individual stat totals. JSON backup is for restoring the app and is not the spreadsheet import format.
- To implement automatic Google Sheets sync, the app owner must create a Google Cloud project, enable the Google Sheets API, configure the OAuth consent screen and authorized web origin, create a browser OAuth client ID, and implement Google sign-in/authorization plus Sheets API read/write calls. The deployed app must be configured with that client ID and OAuth flow. Do not embed a Google client secret in this public static app.
- Calendar import accepts public `.ics` feed URLs only when the provider allows browser CORS access. Many private calendar feeds will not work.
- Custom sport names can be added, but custom stat categories are currently a general set rather than an editable per-sport stat builder.

## Publish on GitHub Pages
1. Download and unzip this package.
2. Back up data from the old app on the device before replacing files.
3. Upload the contents of this folder to the root of the same GitHub repository.
4. In GitHub, open **Settings → Pages** and retain the current branch/root publishing configuration.
5. Wait for deployment, then reload the site. The service-worker cache is versioned as `sports-stats-v4`.
6. On iPhone, open the site in Safari and use **Share → Add to Home Screen** if needed.

## Scoring notes
- A goal counts as a goal, shot attempt, and shot on goal.
- A shot-on-goal entry counts as an attempt and a shot on goal.
- Shooting percentage = goals / shot attempts.
- Shots-on-goal percentage = shots on goal / shot attempts.
- A saved game counts as a game played for each roster player in season totals.
- Penalty minutes are recorded as assessed minutes; early-ending minors remain recorded at their assessed minutes for PIM totals.
- The shift timer tracks one player at a time.

This is a volunteer scorekeeping aid, not an official league scoring system. Confirm league-specific rules before using reports as official records.
