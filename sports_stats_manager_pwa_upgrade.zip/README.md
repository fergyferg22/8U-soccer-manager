# Sports Stats Manager PWA

A free, mobile-friendly, installable scorebook for Hockey, Soccer, and Lacrosse.

## Upgrade and data preservation
This upgrade retains the original IndexedDB database name (`eightUManagerDB`) and object store (`state`) used by the 8U Soccer Manager. On first launch, the app detects the legacy single-team schema, first saves an untouched copy under the IndexedDB key `legacy_backup_before_sports_upgrade`, then migrates the roster, saved games, current match, team name, and team colors into the new season/team structure. Existing soccer games are labeled Soccer.

**Before replacing the files on GitHub Pages:** open the old app on the device that contains your records and download a JSON backup. Keep that backup somewhere safe. Then publish these upgraded files to the same repository and open the app on the same browser profile. Do not clear browser/site data during the upgrade.

## Included
- Sport selection: Hockey, Soccer, Lacrosse
- Named seasons and teams
- Team-specific accent and secondary colors
- Roster with jersey numbers and positions
- Manual game details: type, opponent, rink/field, date, time, home/away and position
- Live scoreboard with +/- score correction
- Goals, assists, scoring zone and net location
- Shot attempts and shots on goal
- Faceoff wins, hits, blocked shots, takeaways, giveaways and plus/minus controls
- Shift timer and manual shift entry
- Penalty logging: minor, double minor, major, misconduct and game misconduct; minor can be marked ended early after an opposing power-play goal
- Shootout attempts by player and result
- Game notes and final W/L/T
- Schedule filters: All, Played, Upcoming; review saved games
- Season player totals, shooting percentages, ice time, shifts and scoring milestones
- Trend chart, CSV export, JSON backup and restore
- Offline PWA cache after first successful online load

## Publish on GitHub Pages
1. Download and unzip this package.
2. Back up the old app data from the device before replacing files.
3. Upload the contents of this folder to the root of the same GitHub repository, replacing the old app files.
4. In GitHub, open **Settings → Pages**. Keep **Deploy from a branch**, `main`, and `/ (root)` if that is how the current app is published.
5. Wait for the deployment to finish, then reload the existing site. If an old version remains cached, close the installed PWA/browser tab and reopen the site; the service worker cache has been versioned to `sports-stats-v2`.
6. On iPhone, open the site in Safari and use **Share → Add to Home Screen** if it is not already installed.

## Parent-specific data
Data remains in IndexedDB in the browser profile on each parent's device. Separate parents using their own browser/device installations have separate data. This version does not provide cloud accounts, family login, or automatic synchronization between parents/devices. Use JSON backups to transfer or restore data.

## Google Sheets and calendar import limitations
- CSV export is implemented and can be imported into Google Sheets.
- Direct Google Sheets OAuth synchronization is **not enabled** in this package. It requires a Google Cloud project, OAuth client configuration, and Sheets API setup. The app explains this when the Google Sheets setup button is selected.
- Calendar import accepts a public `.ics` feed URL only when the hosting provider allows browser cross-origin access (CORS). Many private Google/Apple calendar links will not permit direct browser fetch. If import fails, enter the game manually.

## Scoring notes
- A recorded goal counts as a goal, shot attempt, and shot on goal.
- A shot-on-goal entry counts as both an attempt and a shot on goal.
- Shooting percentage = goals / shot attempts.
- Shots-on-goal percentage = shots on goal / shot attempts.
- A saved game counts as a game played for each roster player in season totals.
- Penalty minutes are recorded as the assessed minutes. An early-ending minor remains recorded as a 2-minute penalty for PIM totals.
- Shift timer records one active player's shift at a time.

This is a volunteer scorekeeping aid, not an official league scoring system. Confirm league-specific rules and statistics before using reports as official records.
